//#define DEBUG

#include <stdlib.h>
#include <ShiftOut.h>
#include <wiring.h>

#ifdef DEBUG
#include <HardwareSerial.h>
#endif

/*
  ShiftOut.cpp - 74HC959 Control Library
  Author: GusPS, http://gusps.blogspot.com/
  Copyright (c) 2009.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

ShiftOut::ShiftOut(uint8_t latchPin, uint8_t clockPin, uint8_t dataPin, uint8_t registersCount)
	: _latchPin(latchPin), _clockPin(clockPin), _dataPin(dataPin), _registersCount(registersCount)
{
#ifdef DEBUG
Serial.begin(9600);
Serial.println("ShiftOut");
#endif
	pinMode(_latchPin, OUTPUT);
	pinMode(_clockPin, OUTPUT);
	pinMode(_dataPin, OUTPUT);

	_values = (uint8_t*) malloc(_registersCount * sizeof(uint8_t));

	_createdOk = (_values != 0);

	for (int i = 0; i < _registersCount; i++)
		_values[i] = 0;

	sendData();
}

bool ShiftOut::isOk()
{
	return _createdOk;
}

void ShiftOut::digitalWrt(uint8_t pin, int value)
{
	setData(pin, value);
	sendData();
}


void ShiftOut::digitalWrtFull(uint8_t regis, int fullValue)
{
	_values[regis] = fullValue;
	sendData();
}

void ShiftOut::setData(uint8_t pin, int value)
{
	uint8_t regis = pin / 8;
	uint8_t bit = pin % 8;
	if (value == HIGH)
		_values[regis] |= 1<<bit;
	else
		_values[regis] &= ~(1<<bit);
}

void ShiftOut::sendData()
{
	if (_createdOk)
	{	
		digitalWrite(_latchPin, 0);

		digitalWrite(_dataPin, 0);

		for (int i = _registersCount - 1; i >= 0; i--)
		{
#ifdef DEBUG
				Serial.print("R");
				Serial.print(i + 1);
				Serial.print(" || ");
#endif
			uint8_t value = _values[i]; 
			for (int j = 7; j >= 0; j--)
			{
#ifdef DEBUG
				Serial.print("Q");
				Serial.print(j);
				Serial.print("=");
#endif
				digitalWrite(_clockPin, 0);

			    if (value & (1<<j))
				{
#ifdef DEBUG
					Serial.print("1 | ");
#endif
					digitalWrite(_dataPin, 1);
				} else {
#ifdef DEBUG
					Serial.print("0 | ");
#endif
					digitalWrite(_dataPin, 0);
				}

			    digitalWrite(_clockPin, 1);
				digitalWrite(_dataPin, 0);
			}
#ifdef DEBUG
			Serial.println("");
#endif
		}
		digitalWrite(_clockPin, 0);

		digitalWrite(_latchPin, 1);
	}
}
